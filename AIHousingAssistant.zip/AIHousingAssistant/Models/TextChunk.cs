﻿namespace AIHousingAssistant.Models
{
    public class TextChunk
    {
        public int Index { get; set; }
        public string Content { get; set; }
        public string Source { get; set; }   

    }

}
