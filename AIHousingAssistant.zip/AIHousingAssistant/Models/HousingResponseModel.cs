﻿namespace AIHousingAssistant.Models
{
    public class HousingResponseModel
    {
    }
}
