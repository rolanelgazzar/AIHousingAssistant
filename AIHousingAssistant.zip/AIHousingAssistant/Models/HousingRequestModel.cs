﻿namespace AIHousingAssistant.Models
{
    public class HousingRequestModel
    {
    }
}
