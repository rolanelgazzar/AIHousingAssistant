﻿namespace AIHousingAssistant.Models
{
    //public class ChatMessage
    //{
    //    public string Role { get; set; }  // "User" | "Assistant" | "System"
    //    public string Content { get; set; }
    //    public DateTime Timestamp { get; set; }
    //}
}
