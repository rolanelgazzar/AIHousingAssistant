﻿namespace AIHousingAssistant.Application.Enum
{
    public enum ChunkingMode
    {
        SemanticTextSplitter,
        SemanticTextBlocksGrouper,
        RecursiveTextSplitter,
        LangChainRecursiveTextSplitter
    }
}
