﻿namespace AIHousingAssistant.Application.Enum
{
    public enum VectorStoreProvider
    {
        InMemory = 0,
        QdrantSdk = 1,
        QdrantSemanticKernel = 2
    }

}
