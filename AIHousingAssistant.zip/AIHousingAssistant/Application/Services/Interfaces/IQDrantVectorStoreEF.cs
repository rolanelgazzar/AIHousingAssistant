﻿using AIHousingAssistant.Application.Services.VectorStores;

namespace AIHousingAssistant.Application.Services.Interfaces
{
    public interface IQDrantVectorStoreEF: IVectorStore
    {
    }
}
