﻿namespace AIHousingAssistant.Application.Services.Interfaces
{
    public interface IQDrantVectorStore:IVectorStore
    {
    }
}
