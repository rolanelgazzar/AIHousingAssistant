﻿using Microsoft.Extensions.VectorData;

namespace AIHousingAssistant.Application.Services.Interfaces
{
    public interface IInMemoryVectorStore:IVectorStore
    {
    }
}
