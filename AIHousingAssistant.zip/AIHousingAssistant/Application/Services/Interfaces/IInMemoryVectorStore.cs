﻿using AIHousingAssistant.Application.Services.VectorStores;
using Microsoft.Extensions.VectorData;

namespace AIHousingAssistant.Application.Services
{
    public interface IInMemoryVectorStore:IVectorStore
    {
    }
}
