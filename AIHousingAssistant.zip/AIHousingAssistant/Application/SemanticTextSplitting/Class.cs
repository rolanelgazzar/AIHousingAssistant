﻿namespace AIHousingAssistant.Application.SemanticTextSplitting
{
    public class Class
    {
    }
}
